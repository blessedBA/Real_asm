                          ProxyFTP REGISTRATION FORM

          (Please answer questions required for registration and send
          it to proxykit@newmail.ru   Subject: ProxyFTP: REGISTRATION)

          * - Required fields.


*         Name: ______________________________________________________

       Company: ______________________________________________________

          City: ______________________________________________________

State/Province: ______________________________________________________

   Zip/Country: ______________________________________________________

*       E-mail: ____________________ *E-mail: ________________________
                      (FidoNet)                      (internet)



*  FAR version: ____________________     *OS: ________________________

*  ProxyFtp version: _________________________________________________

*  Connection type (Direct, via Proxy server, type of your Proxy server)

                ______________________________________________________
